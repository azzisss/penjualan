

<?php $__env->startSection('mainkonten'); ?>
<div class="container-fluid px-4 mt-4">
	<h1 class="">Makanan</h1>
		<ol class="breadcrumb mb-2 ">
			<li class="breadcrumb-item active">Makanan</li>
		</ol>
		<hr>
	<?php if( session()->has('berhasil')): ?>
	<div class="alert alert-success alert-dismissible fade show text-capitalize text-center fw-semibold fs-6 mt-2" role="alert">
		<?php echo e(session('berhasil')); ?>

		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
	</div>
	<?php elseif(session()->has('hapus')): ?>
	<div class="alert alert-danger alert-dismissible fade show text-capitalize text-center fw-semibold fs-6 mt-2" role="alert">
		<?php echo e(session('hapus')); ?>

		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
	</div>
	<?php elseif(session()->has('update')): ?>
	<div class="alert alert-warning alert-dismissible fade show text-capitalize text-center fw-semibold fs-6 mt-2" role="alert">
		<?php echo e(session('update')); ?>

		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
	</div>
	<?php endif; ?> 
	<div class="card my-4">
		<div class="fs-6">
			<div class="card-header text-center">
				<h5>Data Makanan</h5>
			</div>
			<div class="card-body">
				<div class="row justify-content-start">
					<div class="col-sm-3">
						<a href="/makanan/create" class="btn btn-success mb-2"> Tambah Data Makanan </a>
					</div>
					<div class="col-sm-3">
						<form action="/makanan" method="get">	
							<div class="input-group mb-3">
								<select class="form-select" id="category" name="category">
									<option value="" selected> Semua Kategori</option>
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($category->nama_category); ?>"> <?php echo e($category->nama_category); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
									<button class="btn btn-outline-primary border" type="submit">Pilih</button>
								</div>
							</form>
					</div>
					<div class="col-sm-3">
						<div class="mb-3">
							<form action="/makanan" method="get">			
										<div class="input-group mb-3">
								<input type="text" class="form-control" placeholder="Search.." name="search" value="<?php echo e(request('search')); ?>" >
								<button class="btn btn-outline-primary border" type="submit">Search</button>
										</div>
								</form>
						</div>
					</div>
				</div>
				<div class="table-responsive">
					<table id='example' class="table table-bordered" >
						<thead>
							<tr>
								<th scope="col" class="no text-center">
									No
								</th>
								<th scope="col" class="text-center">Gambar</th>
							<th scope="col" >
								Nama Makanan						
							</th>
							<th scope="col" class="text-center">Keterangan</th>
							<th scope="col" class="text-center">Harga</th>
							<th scope="col" class="text-center">Kategori</th>
							<th scope="col" class="text-center">Action</th>
								</tr>
						</thead>
						<tbody class="table-group-divider">
							<?php $__currentLoopData = $makanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $makanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
										<th scope="row" class="no text-center"><?php echo e($loop->iteration); ?></th>
										<td class="text-center">
											<?php if($makanan->gambar): ?>
											<img src="<?php echo e(asset('storage/'. $makanan->gambar)); ?>" alt="" style="cursor: pointer;" data-bs-toggle="modal" href="#exampleModalToggle<?php echo e($col++); ?>" class="img-fluid" height="40" width="50">
											<div class="modal fade" id="exampleModalToggle<?php echo e($col2++); ?>" aria-hidden="true"  tabindex="-1">
												<div class="modal-dialog modal-dialog-centered">
														<div class="modal-content">
																<div class="modal-header">
																		<h5 class="modal-title" id="exampleModalToggleLabel"><?php echo e($makanan->nama_makanan); ?></h5>
																		<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
																</div>
																<div class="modal-body">
																	<img src="<?php echo e(asset('storage/'. $makanan->gambar)); ?>" class="img-fluid" >
																</div>
																<div class="modal-footer">
																</div>
														</div>
												</div>
											</div>
											<?php else: ?>
											<?php endif; ?>
										</td>
										<td ><?php echo e($makanan->nama_makanan); ?></td>
										<td ><?php echo e($makanan->keterangan_makanan); ?></td>
										<td > Rp. <?php echo e($makanan->harga_makanan); ?></td>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($makanan->category_id==$category->id): ?> 
										<td ><?php echo e($category->nama_category); ?></td>
									<?php endif; ?> 
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<td class="text-center">
									<a href="/makanan/<?php echo e($makanan->id); ?>/edit" class="btn btn-warning btn-sm mx-1 my-0.5">
										<i class="bi bi-pencil-square fs-6"></i>
									</a>
									<form action="/makanan/<?php echo e($makanan->id); ?>" method="post" class="d-inline">
									<?php echo method_field('delete'); ?>
									<?php echo csrf_field(); ?>
									<button class="btn btn-danger btn-sm mx-1 my-0.5 border-0" onclick="return confirm('Yakin Akan di Hapus?')" >
										<i class="bi bi-trash-fill fs-6" ></i>
									</button>
								</form>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
				</div>
			</div>
		</div>
	</div>

	<script>
		$(document).ready(function () {
					$('#example').DataTable({
						searching: false,
					});
	});
	</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/makanan/index.blade.php ENDPATH**/ ?>