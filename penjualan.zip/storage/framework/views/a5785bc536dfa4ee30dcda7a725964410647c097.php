

<?php $__env->startSection('mainkonten'); ?>
<div class="container-fluid px-4 mt-4 mb-3">
	<h1 class="">Operator</h1>
		<ol class="breadcrumb mb-2 ">
			<li class="breadcrumb-item active">Operator</li>
		</ol>
		<hr>
	<?php echo $__env->make('partials.massage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="row justify-content-center">
		<div class="col-10">
			<div class="card">
				<div class="card-header">
					<h5 class="text-center">Operator</h5>
				</div>
				<div class="card-body">
					<a href="/operator/create" class="btn btn-success mb-2"> Tambah Operator </a>
					<div class="table-responsive">
						<table id="example" class="table table-bordered border-primary" >
							<thead>
								<tr>
									<th>No</th>
									<th>Nama Operator</th>
									<th>Username</th>
									<th>email</th>
									<th>Akses</th>
									<th>Operasi</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $operator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<th><?php echo e($loop->iteration); ?></th>
									<td><?php echo e($item->name); ?></td>
									<td><?php echo e($item->username); ?></td>
									<td><?php echo e($item->email); ?></td>
									<?php $__currentLoopData = $akses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemakses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if($item->id_akses == $itemakses->id): ?>
																	<td><?php echo e($itemakses->nama_akses); ?></td>
													<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<td class="text-center">
										<button class="btn btn-warning btn-sm mx-1 my-0.5 border-0">
											<a href="/operator/<?php echo e($item->id); ?>/edit"  style="text-decoration: none; color:white;">
												<i class="bi bi-pencil-square"></i>ubah
											</a>
	
										</button>
										<?php if(count($operator) <= 1): ?>
											<button class="btn btn-danger btn-sm mx-1 my-0.5 border-0" disabled>
											<i class="bi bi-trash-fill" ></i>hapus
										</button>
										<?php else: ?>
											<form action="/operator/<?php echo e($item->id); ?>" method="post" class="d-inline">
											<?php echo method_field('delete'); ?>
											<?php echo csrf_field(); ?>
											<button class="btn btn-danger btn-sm mx-1 my-0.5 border-0" onclick="return confirm('Yakin Akan di Hapus?')" >
												<i class="bi bi-trash-fill" ></i>hapus
											</button>
											</form>
										<?php endif; ?>
									</td>
								</tr>
										
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script>
	$(document).ready(function () {
	 $('#example').DataTable();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/operator/operator.blade.php ENDPATH**/ ?>