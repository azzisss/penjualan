

<?php $__env->startSection('mainkonten'); ?>
<div class="container-fluid px-4">
	<h1 class="mt-4">Laporan</h1>
	<ol class="breadcrumb mb-4">
		 <li class="breadcrumb-item active">Laporan</li>
		 <li class="breadcrumb-item active" aria-current="page">Hari ini</li>
	</ol>
	<div class="row mb-3 justify-content-center">
		<div class=" col-sm-3">
			<div class="card border-secondary mb-2" style="height: 6.5em">
				<div class="card-header bg-secondary text-white">
					Hari / Tanggal
				</div>
				<div class="card-body">
					<h6 class="text-center"><?php echo e($hariini); ?></h6>
				</div>
			</div>
		</div>
		<div class="col-sm-3">
			<div class="card border-primary mb-2" style="height: 6.5em">
				<div class="card-header bg-primary text-white">
					Makanan Terjual
				</div>
				<div class="card-body">
					<h5 class="card-title text-center" ><?php echo e($mkntrjl); ?> Makanan</h5>
				</div>
			</div>
		</div>
		<div class="col-sm-3">
			<div class="card border-success mb-2" style="height: 6.5em">
				<div class="card-header bg-success text-white">
					Pendapatan
				</div>
				<div class="card-body">
					<h5 class="card-title text-center">Rp. <?php echo e(number_format($pendapatan,2,",",".")); ?></h5>
				</div>
			</div>
		</div>
	</div>
	<div class="row mb-3 justify-content-center">
		
		<div class="col-sm-10">
			<div class="card">
				<div class="card-header text-center">
					<h5>Laporan Harian</h5>
				</div>
				<div class="card-body">
					<?php
						use App\Models\Checkout;
						// Set your timezone
						date_default_timezone_set('Asia/Jakarta');

						// Get prev & next month
						if (isset($_GET['ym'])) {
								$ym = $_GET['ym'];
						} else {
								// This month
								$ym = date('Y-m');
						}

						// Check format
						$timestamp = strtotime($ym . '-01');
						if ($timestamp === false) {
								$ym = date('Y-m');
								$timestamp = strtotime($ym . '-01');
						}

						// Today
						$today = date('Y-m-j', time());

						// For H3 title
						$month = date('F - Y', $timestamp);

						
						// You can also use strtotime!
						$prev = date('Y-m', strtotime('-1 month', $timestamp));
						$next = date('Y-m', strtotime('+1 month', $timestamp));

						// Number of days in the month
						$day_count = date('t', $timestamp);
						
						// 0:Sun 1:Mon 2:Tue ...
						$str = date('w', mktime(0, 0, 0, date('m', $timestamp), 1, date('Y', $timestamp)));
						//$str = date('w', $timestamp);


						// Create Calendar!!
						$weeks = array();
						$week = '';

						// Add empty cell
						$week .= str_repeat('<td></td>', $str);

						for ( $day = 1; $day <= $day_count; $day++, $str++) {
								
								$date = $ym . '-' . $day;
								
								if ($today == $date) {
										$week .= '<td class="bg-primary fs-6">' . $day . '<br><b>' . 'Rp' . number_format(Checkout::whereDate('created_at', $date )->get()->sum('total_bayar'),0,",",".");
								} else {
										$week .= '<td>' . $day . '<br> <b>' . 'Rp ' . number_format(Checkout::whereDate('created_at', $date )->get()->sum('total_bayar'),0,",",".");
								}
								$week .= '</td>';
								
								// End of the week OR End of the month
								if ($str % 7 == 6 || $day == $day_count) {

										if ($day == $day_count) {
												// Add empty cell
												$week .= str_repeat('<td></td>', 6 - ($str % 7));
										}

										$weeks[] = '<tr>' . $week . '</tr>';

										// Prepare for new week
										$week = '';
								}

						}		
					?>
					<div class="text-center">
						<div class="d-flex justify-content-evenly">
							<h3><a class="btn btn-primary" href="?ym=<?php echo e($prev); ?>"><<</a></h3>
							<h3><?php echo e($month); ?></h3>
							<h3><a class="btn btn-primary" href="?ym=<?php echo e($next); ?>">>></a></h3>
						</div>
					</div>
					<div class="table-responsive">
						<table class="table table-bordered border-primary table-success">
							<thead>
								<th>Ahad</th>
								<th>Senin</th>
								<th>Selasa</th>
								<th>Rabu</th>
								<th>Kamis</th>
								<th>Jumat</th>
								<th>Sabtu</th>
							</thead>
							<tbody class="text-center">
								<?php
									foreach ($weeks as $week) {
										echo $week;
									}
								?>
							</tbody>
						</table>

					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row mb-3 justify-content-center">
		<div class="col-10">
			<div class="card">
				<div class="card-header">
					<h5 class="card-title text-center" >Laporan Checkout Hari Ini</h5>
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table id="example" class="table table-hover" style="width:100%">
							<thead>
								<tr>
										<th>No</th>
										<th>No Pesanan</th>
										<th>User</th>
										<th>Total Harga</th>
										<th>Diskon</th>
										<th>Total Bayar</th>
										<th>Tunai</th>
										<th>Kembali</th>
										<th>Waktu</th>
										<th>Detail</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $tabelC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e($item->no_pesanan); ?></td>
									<td><?php echo e($item->user); ?></td>
									<td>Rp. <?php echo e(number_format($item->total_harga)); ?></td>
									<td><?php echo e($item->diskon); ?> %</td>
									<td>Rp. <?php echo e(number_format($item->total_bayar)); ?></td>
									<td>Rp. <?php echo e(number_format($item->tunai)); ?></td>
									<td>Rp. <?php echo e(number_format($item->kembali)); ?></td>
									<td><?php echo e($item->created_at); ?></td>
									<td>
										<a href="/show/<?php echo e($item->id); ?>" class="badge bg-info mx-1 my-0.5">
											<i class="bi bi-eye fs-6"></i>
									</a></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					
				</div>
			</div>
		</div>
	</div>
	<div class="row mb-3 justify-content-center">
		<div class="col-sm-10">
			<div class="card">
				<div class="card-header">
					<h5>Makanan Terjual</h5>
				</div>
				<div class="card-body">
					<table id="example2" class="table table-hover" style="width:100%">
						<thead>
								<tr>
										<th>No</th>
										<th>Nama Makanan</th>
										<th>Terjual</th>
								</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $tabelMT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($loop->iteration); ?></td>
								<td><?php echo e($item->nama_makanan); ?></td>
								<td><?php echo e($item->sum); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

				</div>
			</div>
		</div>
	</div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script>
	$(document).ready(function () {
    $('#example').DataTable();
    $('#example2').DataTable();
				calender();
				getmonth();
				getyear();
});
</script>
<script>

function calender(){
	var cal = $('.days').html('');
	$.ajax({
		type: "get",
		url: "/calender",
		success: function (response) {
			$('.days').html(response);
		}
	});

}
function getmonth() {
	var month = $('.m').html('');
	$.ajax({
		type: "get",
		url: "/smonth",
		success: function (response) {
			$('.m').html(response);
		}
	});
}
function getyear() {
	$.ajax({
		type: "get",
		url: "/getyear",
		success: function (response) {
			$('.y').html(response);

		}
	});
}
function prevmonth() {
	$.ajax({
		type: "get",
		url: "/prevmonth",
		success: function (response) {
			getmonth();
		}
	});
}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/laporan/day.blade.php ENDPATH**/ ?>