<div class="modal fade" id="exampleModal1" aria-hidden="true"  tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true">
 <div class="modal-dialog">
       <div class="modal-content">
             <div class="modal-header">
             </div>
             <div class="modal-body text-center">
                Yakin Akan Hapus Keranjang?
             </div>
             <div class="modal-footer justify-content-center">
                <form action="/deletecart" method="post">
                   <?php echo csrf_field(); ?>
                   <button type="button" class="btn btn-danger" data-bs-dismiss="modal">&nbsp;&nbsp; Tidak<i class="bi bi-x"></i> &nbsp;&nbsp;</button>
                   &nbsp;&nbsp;&nbsp;&nbsp;
                   <button type="submit" class="btn btn-success" id="myBtn">&nbsp;&nbsp; Iya<i class="bi bi-check2"></i> &nbsp;&nbsp;</button>
                </form>
             </div>
       </div>
 </div>
</div><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/penjualan/ModalDelete.blade.php ENDPATH**/ ?>