
<?php $__env->startSection('mainkonten'); ?>


<div class="container-fluid px-3 mt-4">
	<div class="row">
		<div class="d-flex justify-content-evenly flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h3 style="text-transform:capitalize" class="h4">Edit Makanan</h3>
		</div>
		<div class="d-flex justify-content-center">
			<div class="col-lg-8">
	
				<form method="post" action="/makanan/posts/<?php echo e($makanan->id); ?>/edit">
					<?php echo method_field('put'); ?>
					<?php echo csrf_field(); ?>
					<div class="mb-3">
						<label for="nama_makanan" class="form-label">Nama Makanan</label>
						<input type="text" class="form-control <?php $__errorArgs = ['nama_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_makanan" name="nama_makanan" required value="<?php echo e(old('nama_makanan',$makanan->nama_makanan)); ?>">
	
						<?php $__errorArgs = ['nama_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="nama_makanan">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	
					</div>
					<div class="mb-3">
						<label for="keterangan_makanan" class="form-label">Slug</label>
						<input type="text" class="form-control <?php $__errorArgs = ['keterangan_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="keterangan_makanan" name="keterangan_makanan"  value="<?php echo e(old('keterangan_makanan',$makanan->keterangan_makanan)); ?>">
	
						<?php $__errorArgs = ['keterangan_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="keterangan_makanan">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	
					</div>
	
					<div class="mb-3">
						<label for="category_id" class="form-label" aria-label="Default select example">Kategori Makanan</label>
						<select class="form-select" id="category_id" name="category_id">
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if(old('category_id',$makanan->category_id)==$category->id): ?>
							<option value="<?php echo e($category->id); ?>" selected> <?php echo e($category->nama_category); ?></option>
							<?php else: ?>
							<option value="<?php echo e($category->id); ?>"> <?php echo e($category->nama_category); ?></option>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
						</select>
					</div>
	
					<div class="mb-3">
						<label for="harga_makanan" class="form-label">Harga Makanan</label>
						<input type="number" min="0" class="form-control <?php $__errorArgs = ['harga_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga_makanan" name="harga_makanan" required value="<?php echo e(old('harga_makanan',$makanan->harga_makanan)); ?>">
	
						<?php $__errorArgs = ['harga_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="harga_makanan">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	
					</div>
	
					<div class="mb-3">
						<label for="gambar" class="form-label <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Gambar Makanan</label>
						<input class="form-control" type="file" id="gambar" name="gambar">
	
						<?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="gambar">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
	
					<button type="submit" class="btn btn-primary">Update Makanan</button>
				</form>
	
			</div>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/makanan/posts/edit.blade.php ENDPATH**/ ?>