
<?php $__env->startSection('mainkonten'); ?>


<div class="container-fluid px-4 mt-4">
	<h1 class="">Makanan</h1>
					<ol class="breadcrumb mb-2 ">
									<li class="breadcrumb-item"> <a href="/makanan">Makanan</a></li>
									<li class="breadcrumb-item active">Edit</li>
					</ol>
	<hr>
	<div class="row">
		<div class="d-flex justify-content-evenly flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 ">
			<h3 style="text-transform:capitalize" class="h4">Edit Makanan</h3>
		</div>
		<div class="d-flex justify-content-center">
			<div class="col-lg-8">
	
				<form method="post" action="/makanan/<?php echo e($makanan->id); ?> " enctype="multipart/form-data">
					<?php echo method_field('put'); ?>
					<?php echo csrf_field(); ?>
					<div class="mb-3">
						<label for="nama_makanan" class="form-label">Nama Makanan</label>
						<input type="text" class="form-control <?php $__errorArgs = ['nama_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_makanan" name="nama_makanan" required value="<?php echo e(old('nama_makanan',$makanan->nama_makanan)); ?>">
	
						<?php $__errorArgs = ['nama_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="nama_makanan">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	
					</div>
					<div class="mb-3">
						<label for="keterangan_makanan" class="form-label">Keterangan Makanan</label>
						<input type="text" class="form-control <?php $__errorArgs = ['keterangan_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="keterangan_makanan" name="keterangan_makanan"  value="<?php echo e(old('keterangan_makanan',$makanan->keterangan_makanan)); ?>">
	
						<?php $__errorArgs = ['keterangan_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="keterangan_makanan">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	
					</div>
	
					<div class="mb-3">
						<label for="category_id" class="form-label" aria-label="Default select example">Kategori Makanan</label>
						<select class="form-select" id="category_id" name="category_id">
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if(old('category_id',$makanan->category_id)==$category->id): ?>
							<option value="<?php echo e($category->id); ?>" selected> <?php echo e($category->nama_category); ?></option>
							<?php else: ?>
							<option value="<?php echo e($category->id); ?>"> <?php echo e($category->nama_category); ?></option>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
						</select>
					</div>
	
					<label for="harga_makanan" class="form-label">Harga Makanan</label>
					<div class="input-group mb-3">
						<span class="input-group-text" id="basic-addon1">Rp.</span>
						<input type="number" min="0" oninput="this.value = Math.abs(this.value)" class="form-control <?php $__errorArgs = ['harga_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga_makanan" name="harga_makanan" required value="<?php echo e(old('harga_makanan',$makanan->harga_makanan)); ?>">
	
						<?php $__errorArgs = ['harga_makanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="harga_makanan">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	
					</div>
	
					<div class="mb-3">
						<label for="gambar" class="form-label <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Gambar Makanan</label>
						<input type="hidden" name="gambarlama" value="<?php echo e($makanan->gambar); ?>">
						<?php if($makanan->gambar): ?>
						<img src="<?php echo e(asset('storage/'. $makanan->gambar)); ?>" class="img-preview img-fluid col-sm-5 mb-3 d-block">
						<?php else: ?>
						<img class="img-preview img-fluid col-sm-5 mb-3">
						<?php endif; ?>
						<input class="form-control" type="file" id="gambar" name="gambar" onchange="previewImage()">

						<?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="gambar">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
	
					<button type="submit" class="btn btn-primary">Update Makanan</button>
				</form>
	
			</div>
		</div>
	</div>
</div>

<script>
function previewImage(){
	
	const gambar = document.querySelector('#gambar');
	const imgPreview = document.querySelector('.img-preview');

	imgPreview.style.display = 'block'; 

	const oFReader = new FileReader();
	oFReader.readAsDataURL(gambar.files[0]);

	oFReader.onload = function(oFREvent){
		imgPreview.src = oFREvent.target.result;
	}

}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/makanan/edit.blade.php ENDPATH**/ ?>