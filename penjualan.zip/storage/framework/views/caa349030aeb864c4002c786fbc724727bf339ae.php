

<?php $__env->startSection('mainkonten'); ?>
<div class="card mb-4">
	<div class="card-header">
		 <i class="fas fa-table me-1"></i>
		 Data Kategori Makanan
	</div>
	<div class="card-body">
		 <table id="datatablesSimple">
			  <thead>
					<tr>
						 <th>No</th>
						 <th>Nama Kategori</th>
						 <th>Action</th>
					</tr>
			  </thead>
			  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  <tbody>
					<tr>
						<td><?php echo e($loop->iteration); ?></td>
						<td><?php echo e($category->nama_category); ?></td>
						<td class="text-center">
							<a href="/dashboard/posts/<?php echo e($p->slug); ?>" class="badge bg-info mx-1 my-0.5">
								 <span style="width: 24px; height: 24px; "data-feather="file-text"></span>
							</a>
							<a href="/dashboard/posts/<?php echo e($p->slug); ?>/edit" class="badge bg-warning mx-1 my-0.5">
								 <span  style="width: 24px; height: 24px;" data-feather="edit"></span>
							</a>
							<form action="/dashboard/posts/<?php echo e($p->slug); ?>" method="post" class="d-inline">
							<?php echo method_field('delete'); ?>
							<?php echo csrf_field(); ?>
							<button class="badge bg-danger mx-1 my-0.5 border-0" onclick="return confirm('Yakin Akan di Hapus?')" > <span style="width: 24px; height: 24px;" data-feather="delete"></span></button>
							</form>
						 </td>
					</tr>
			  </tbody>
		 </table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/category.blade.php ENDPATH**/ ?>