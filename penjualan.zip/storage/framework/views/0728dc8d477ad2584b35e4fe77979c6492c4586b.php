<div>
    
    <div class="col-lg-5">
        <div class="sticky-lg-top">
            <div class="card mb-3 brdblue">
                <div class="card-header border-primary ">
                    <h5 class="mb-0 ">Order</h5>
                </div>
                <div class="card-body">
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Item</th>
                                <th scope="col">Harga</th>
                                <th scope="col"class="text-center">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cartitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="col-4"> <?php echo e($loop->iteration); ?> </th>
                                    <td scope="row">
                                        <p class="text-start fw-normal lh-sm">
                                            <?php echo e($item->nama_makanan); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <p class="text-start fw-normal lh-sm">
                                            Rp <?php echo e(number_format($item->harga_makanan, 0, ',', '.')); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-start">
                                            <form action="/cart/<?php echo e($item->id); ?>" method="post">
                                                <?php echo method_field('patch'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="param" value="kurang">
                                                <input type="hidden" name="qty" value="<?php echo e($item->qty); ?>">
                                                <button class="btn btn-link btn-sm border-primary "
                                                    style="margin-right: -1px;border-top-right-radius: 0; border-bottom-right-radius: 0;"
                                                    onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
                                                    <i class="fas fa-minus"></i>
                                                </button>
                                            </form>

                                            <form action="/updateqty/<?php echo e($item->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input min="0" name="qty" value="<?php echo e($item->qty); ?>"
                                                    type="number" style="width: 4em" id="myInput"
                                                    class="form-control form-control-sm border-primary rounded-0" />
                                                <button type="submit" id="myBtn" hidden></button>
                                            </form>


                                            <form action="/cart/<?php echo e($item->id); ?>" method="post">
                                                <?php echo method_field('patch'); ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="param" value="tambah">
                                                <button class="btn btn-link btn-sm border-primary"
                                                    style="margin-left: -1px;
                                                    border-top-left-radius: 0;
                                                    border-bottom-left-radius: 0;"
                                                    onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="">
                                            <form action="/deletelist/<?php echo e($item->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <button class="btn-sm btn-danger">X</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border">
                                <td colspan="2"><b>Total</b></td>
                                <td colspan="2"><b>Rp <?php echo e(number_format($total, 0, ',', '.')); ?></b></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-end">
                        <?php if($total == 0): ?>
                            <button type="button" class="btn btn-danger me-3" disabled>Hapus</button>
                            <button type="button" class="btn btn-primary" disabled>Checkout</button>
                        <?php else: ?>
                            <button type="button" class="btn btn-danger me-3" data-bs-toggle="modal"
                                href="#exampleModal1">Hapus</button>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                href="#exampleModal2">Checkout</button>
                        <?php endif; ?>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-7">
        <div class="card brdblue card-order1 brdorange">
            <div class="card-header border-primary ">
                <h5 class="mb-0">Daftar Makanan</h5>
            </div>
            <div class="card-body">
                <div
                    class="dropdown d-flex content-start d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                    <a class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                        Kategori
                    </a>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="dropdown-item"
                                    href="#scrollspyHeading<?php echo e($sc++); ?>"><?php echo e($category->nama_category); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="d-flex content-end d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                    <form action="/" method="get">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Search.." name="search"
                                value="<?php echo e(request('search')); ?> " autocomplete="off">
                            <button class="btn btn-primary border" type="submit">Search</button>
                        </div>
                    </form>
                </div>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <hr id="scrollspyHeading<?php echo e($sc2++); ?>">
                    <div class="card border-primary">
                        <div class="card-header d-flex content-start bg-primary border-primary" style="height: 2.5rem">
                            <div class="col-1"></div>
                            <div class="col-8">
                                <p class="text-center mb-1 text-white"><b><?php echo e($category->nama_category); ?></b>
                                <p>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-caret-down-square" data-bs-toggle="collapse"
                                    data-bs-target="#multiCollapseExample<?php echo e($col++); ?>" aria-expanded="true"
                                    style="cursor:pointer"></i>
                            </div>
                        </div>
                        <div class="card-body my-0  brdorange">
                            <div class="collapse.show multi-collapse" id="multiCollapseExample<?php echo e($col2++); ?>">
                                <table class="table table-hover">
                                    <tbody>
                                        <?php $__currentLoopData = $makanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $makanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($makanan->category_id == $category->id): ?>
                                                <tr>
                                                    <td>
                                                        <form action="/cart" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="makanan_id"
                                                                value="<?php echo e($makanan->id); ?>">
                                                            <input type="hidden" name="nama_makanan"
                                                                value="<?php echo e($makanan->nama_makanan); ?>">
                                                            <input type="hidden" name="harga_makanan"
                                                                value="<?php echo e($makanan->harga_makanan); ?>">
                                                            <input type="hidden" name="qty" value="1">
                                                            <input type="hidden" name="subtotal"
                                                                value="<?php echo e($makanan->harga_makanan); ?>">
                                                            <button type="submit" class="btn btn-primary mt-2 ">
                                                                <i class="bi bi-cart-plus"></i>
                                                            </button>
                                                        </form>
                                                    </td>
                                                    <td>
                                                        <?php if($makanan->gambar): ?>
                                                            <img height="60" width="60"
                                                                src="<?php echo e(asset('storage/' . $makanan->gambar)); ?>"
                                                                alt="">
                                                        <?php else: ?>
                                                            <img height="60" width="60"
                                                                src="https://source.unsplash.com/600x400?<?php echo e($makanan->nama_makanan); ?>"
                                                                alt="">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><b><?php echo e($makanan->nama_makanan); ?></b></td>
                                                    <td><?php echo e($makanan->keterangan_makanan); ?></td>
                                                    <td><b>Rp
                                                            <?php echo e(number_format($makanan->harga_makanan, 0, ',', '.')); ?></b>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/livewire/cart.blade.php ENDPATH**/ ?>