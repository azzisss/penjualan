

<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark posit">
	<!-- Navbar Brand-->
	<div class="container">
		<div class="d-flex justify-content-start">

			<img height="50" width="50" src="<?php echo e(asset('/img/logo.png')); ?>" alt="">
			<a class="navbar-brand ps-3" href="/" style="color: rgba(255, 182, 14, 1)">Rm. JagoSore</a>
			
			<?php if(auth()->guard()->check()): ?>
			<!-- Sidebar Toggle-->
			<button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
		</div>
		<div class="d-flex justify-content-end">
			<!-- Navbar Search-->
			<div class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
				<ul class="navbar-nav">
					<li class="nav-item">
					  <a class="nav-link <?php echo e(($active == 'penjualan') ? 'active' : ''); ?>" href="/">Penjualan</a>
					</li>
					<?php if(Auth::user()->id_akses==1): ?>
					<li class="nav-item">
						<a class="nav-link <?php echo e(($active == 'laporan') ? 'active' : ''); ?>" href="/laporan">Laporan</a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php echo e(($active == 'operator') ? 'active' : ''); ?>" href="/operator">Operator</a>
					</li>
					<?php endif; ?>
				 </ul>
				</div>
			<!-- Navbar-->
			  <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
					<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
						<li><a class="dropdown-item text-capitalize">Selamat datang, <?php echo e(auth()->user()->name); ?> </a></li>
						<li><hr class="dropdown-divider" /></li>
						<li>
							<form method="post" action="/logout">
								<?php echo csrf_field(); ?>
									  <button class="dropdown-item">
										 <li><i class="bi bi-box-arrow-right"></i> Logout</li>
									  </button>
								</form>
						</li>
					</ul>
				</li>
			  </ul>
			<?php else: ?>
		
			<?php endif; ?>
		</div>
	</div>
</nav>
        
<?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/partials/navbar.blade.php ENDPATH**/ ?>