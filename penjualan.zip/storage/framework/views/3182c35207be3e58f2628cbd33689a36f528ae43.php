	<div class="col-lg-7">
	<div class="card brdblue card-order1 brdorange">
		<div class="card-header border-primary ">
			<h5 class="mb-0"><?php echo e($fitur2); ?></h5>
		</div>
		<div class="card-body">
			<div class="dropdown d-flex content-start d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
				<a class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" >
					Kategori
				</a>
				<ul class="dropdown-menu" >
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li>
						<a class="dropdown-item" href="#scrollspyHeading<?php echo e($sc++); ?>"><?php echo e($category->nama_category); ?></a>
					</li> 
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<form class="d-flex content-end d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
				<div class="input-group">
					<input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
					<button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
				</div>
			</form>
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<hr id="scrollspyHeading<?php echo e($sc2++); ?>">
			<div class="card border-primary">
				<div class="card-header d-flex content-start bg-primary border-primary" style="height: 2.5rem">
					<div class="col-1"></div>
					<div class="col-8">
						<p class="text-center mb-1 text-white" ><b><?php echo e($category->nama_category); ?></b> <p>
					</div>
					<div class="col-3">
							<i class="bi bi-caret-down-square" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample<?php echo e($col++); ?>" aria-expanded="true" style="cursor:pointer"></i>
					</div>
				</div>
				<div class="card-body my-0  brdorange">
					<div class="collapse.show multi-collapse" id="multiCollapseExample<?php echo e($col2++); ?>">
						<table class="table table-hover">
							<tbody>
								<?php $__currentLoopData = $makanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $makanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($makanan->category_id==$category->id): ?>
								<tr>
									<td >
										<form action="/cart" method="post">
											<?php echo csrf_field(); ?>
											<input type="hidden" name="makanan_id"    value="<?php echo e($makanan->id); ?>">
											<input type="hidden" name="nama_makanan"  value="<?php echo e($makanan->nama_makanan); ?>">
											<input type="hidden" name="harga_makanan" value="<?php echo e($makanan->harga_makanan); ?>">
											<input type="hidden" name="qty"           value="1">
											<input type="hidden" name="subtotal"      value="<?php echo e($makanan->harga_makanan); ?>">
											<button type="submit" class="btn btn-primary mt-2 " >
												<i class="bi bi-cart-plus"></i>
											</button>
										</form>
									</td>
									<td>
										<?php if($makanan->gambar): ?>
										<img height="60" width="60" src="<?php echo e(asset('storage/'. $makanan->gambar)); ?>" alt="">
										<?php else: ?>
											<img height="60" width="60" src="https://source.unsplash.com/600x400?<?php echo e($makanan->nama_makanan); ?>" alt="">
										<?php endif; ?>
									</td>
									<td><b><?php echo e($makanan->nama_makanan); ?></b></td>
									<td><?php echo e($makanan->keterangan_makanan); ?></td>
									<td><b>Rp <?php echo e($makanan->harga_makanan); ?></b></td>
								</tr>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/penjualan/cartP2.blade.php ENDPATH**/ ?>