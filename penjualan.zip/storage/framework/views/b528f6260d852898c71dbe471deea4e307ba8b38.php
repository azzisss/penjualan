

<?php $__env->startSection('mainkonten'); ?>
<div class="container-fluid my-2">
	<div class="row justify-content-center">
		<div class="col-10">
			<div class="card">
				<div class="card-header">
					<h5 class="text-center">Operator</h5>
				</div>
				<div class="card-body">
					<a href="/makanan/create" class="btn btn-success mb-2"> Tambah Data Makanan </a>
					<table id="example" class="table table-bordered border-primary" style="width:100%"">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Operator</th>
								<th>Username</th>
								<th>email</th>
								<th>Akses</th>
								<th>Operasi</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th>1</th>
								<td>Azzis</td>
								<td>Azzis</td>
								<td>azzis@gmail.com</td>
								<td>Admin</td>
								<td class="text-center">
									<a href="" class="badge bg-warning mx-1 my-0.5" style="text-decoration: none">
										<i class="bi bi-pencil-square fs-6"></i>ubah
									</a>
									<form action="" method="post" class="d-inline">
									<?php echo method_field('delete'); ?>
									<?php echo csrf_field(); ?>
									<button class="badge bg-danger mx-1 my-0.5 border-0" onclick="return confirm('Yakin Akan di Hapus?')" >
										<i class="bi bi-trash-fill fs-6" ></i>hapus
									</button>
								</form>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script>
	$(document).ready(function () {
    $('#example').DataTable();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/operator.blade.php ENDPATH**/ ?>