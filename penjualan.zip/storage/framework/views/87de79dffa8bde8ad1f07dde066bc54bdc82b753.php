

<?php $__env->startSection('mainkonten'); ?>

<div id="layoutAuthentication">
    <div id="layoutAuthentication_content">
        <main>
            <?php
                $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                header("Refresh: 7199; URL= $actual_link ");
            ?>
                <input type="hidden" value="<?php echo e($actual_link); ?>">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <?php if(isset ($errors) && count($errors) > 0): ?>
                                <div class="alert alert-warning text-center" role="alert">
                                    <ul class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card shadow-lg border-warning rounded-0">
                            <div class="card-body">
                                <img class="img-thumbnail" src="<?php echo e(asset('/img/logo.png')); ?>" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card shadow-lg border-warning rounded-0 mt-5">
                            <div class="card-header border-danger text-center"><h3>Login</h3></div>
                            <div class="card-body">
                                <form action="/login" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control  rounded-0 <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="username" id="username" placeholder="name@example.com">
                                        <label for="username">Email address or Username</label>
                                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="username">
                                                <?php echo e($message); ?> 
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="password" class="form-control  rounded-0 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password" placeholder="Password">
                                        <label for="password">Password</label>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback" id="password">
                                                <?php echo e($message); ?>

                                            </div> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="d-grid gap-2 col-6 mx-auto">
                                        <button class="btn btn-warning" type="submit"><i class="bi bi-box-arrow-in-up fs-3"></i></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/login/index.blade.php ENDPATH**/ ?>