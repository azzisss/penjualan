
<?php $__env->startSection('mainkonten'); ?>


<div class="container-fluid px-4 mt-4">
	<h1 class="">Operator</h1>
		<ol class="breadcrumb mb-2 ">
   <li class="breadcrumb-item"><a href="/operator">Operator</a></li>
		  <li class="breadcrumb-item"><a href="/operator/<?php echo e($operator->id); ?>/edit">Edit</a> </li>
		  <li class="breadcrumb-item active" aria-current="page">Ubah Password</li>
		</ol>
		<hr>
	<div class="row">
		<div class="d-flex justify-content-evenly flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 ">
			<h3 style="text-transform:capitalize" class="h4">Ubah Password</h3>
		</div>
		<div class="d-flex justify-content-center">
			<div class="col-lg-8">
				<form action="/change/<?php echo e($operator->id); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="mb-3">
						<label for="name" class="form-label">Nama Operator</label>
						<input type="text" readonly class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" required value="<?php echo e(old('name',$operator->name)); ?>">
	
						<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="name">
							<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	
					</div>	  
					<label for="password">Ubah Password</label>
					<div class="input-group mb-3">
						<input type="password"  autocomplete='off' class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" placeholder="password"> 
						<button class="btn btn-secondary btn-sm" type="button" id="eyebutton" onclick="change()">
							<i class="bi bi-eye"></i></button>
							<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback" id="password">
									<?php echo e($message); ?>

								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

					</div>
					<div class="mb-3">
							<label for="password">Konfirmasi Password</label>
						<input type="password" autocomplete='off' class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password2" name="password_confirmation" placeholder="password" >
							<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback" id="password">
										<?php echo e($message); ?> 
								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								
					</div>
					<div class="d-flex justify-content-center">
						<div class="col-3 text-center">
							<button class="btn btn-primary" type="submit">Ubah Password</button>
						</div>

					</div>
				</form>
			
	
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<script>
	function change(){
		var x = document.getElementById("password").type;
		
		if (x == "password"){
			//ubah text
			document.getElementById('password').type = 'text';
			//ubah icon mata tutup
			document.getElementById('eyebutton').innerHTML = '<i class="bi bi-eye-slash"></i>'
		}else if(x == "text"){
			
				//ubah password
				document.getElementById('password').type = 'password';
				//ubah icon mata buka
				document.getElementById('eyebutton').innerHTML = '<i class="bi bi-eye"></i>';
		}
	}
</script>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/operator/changepassindex.blade.php ENDPATH**/ ?>