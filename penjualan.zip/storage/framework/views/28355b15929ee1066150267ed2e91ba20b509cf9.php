
<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Rm.JagoSore 2022</div>
            <div>
                
            </div>
        </div>
    </div>
</footer><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/partials/footer.blade.php ENDPATH**/ ?>