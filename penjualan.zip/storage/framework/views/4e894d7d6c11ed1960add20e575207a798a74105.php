<div class="modal fade" id="exampleModal2" data-bs-backdrop="static" data-bs-keyboard="true">
<div class="modal-dialog modal-lg">
	<div class="modal-content">
				<div class="modal-header">
					<img src="<?php echo e(asset('/img/logo.png')); ?>" class="rounded mx-auto d-block" height="100" width="100" alt="...">
				</div>
				<div class="modal-body">
				<form action="/checkout" method="post">
					<?php echo csrf_field(); ?>
					<table class="table table-bordered">
							<thead>
								<tr>
									<th scope="col" class="text-center">No</th>
									<th scope="col" class="text-center">Item</th>
									<th scope="col" class="text-center">Harga</th>
									<th scope="col" class="text-center">Jumlah</th>
									<th scope="col" class="text-center">Subtotal</th>
									<th></th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $cartitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
										<th class="text-center"><?php echo e($loop->iteration); ?>

											<input type="hidden" name="makanan_id" id="" value="<?php echo e($item->id); ?>">
										</th>
										<td class="fw-semibold"><?php echo e($item->nama_makanan); ?> 
											<input type="hidden" name="nama_makanan" id="" value="<?php echo e($item->nama_makanan); ?>">
										</td>
										<td class="text-center ">Rp. <?php echo e(number_format($item->harga_makanan,2,",",".")); ?>

											<input type="hidden" name="harga_makanan" id="" value="<?php echo e($item->harga_makanan); ?>">
										</td>
										<td class="text-center "><?php echo e($item->qty); ?>

											<input type="hidden" name="qty" id="" value="<?php echo e($item->qty); ?>">
										</td>
										<td class="text-center ">Rp. <?php echo e(number_format($item->subtotal,2,",",".")); ?>

											<input type="hidden" name="subtotal" id="" value="<?php echo e($item->subtotal); ?>">
										</td>
										<td>
											<div class="text-center">
													<button class="btn-sm btn-danger">X</button>

											</div>
										</td>
								</tr>                               
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<tr>
										<td colspan="2" class="text-start" style="border-inline-end-color: white">
											<h4 class="mt-2 ms-2">Total Harga </h4>
										</td>
										<td colspan="3" class="text-center ">
											<input type="hidden" name="total_harga" id="total_harga" value="<?php echo e($total); ?>">
											<h5 class="mt-2 ms-2">Rp <?php echo e(number_format($total,2,",",".")); ?></h5>

										</td>
								</tr>
								<tr class="">
										<td colspan="2" class="text-start " style="border-inline-end-color: white">
											<h4 class="mt-2 ms-2">Diskon </h4>
										</td>
										<td colspan="3" class="fs-5 text-end">
											<div class="input-group mb-0 text-center">
													<input class="form-control-lg border text-center" placeholder="Diskon" min="0" max="100" type="number" name="diskon" id="diskon" onfocus="mulaiHitung()" onblur="stopHitung()" value="0" required style="max-width: 18rem">
													<span class="input-group-text ">%</span>
													
											</div>
										</td>
								</tr>
								<tr>
										<td colspan="2" class="text-start fs-5" style="border-inline-end-color: white">
											<h4 class="mt-2 ms-2">Total Bayar </h4>
										</td>
										<td colspan="3" class="fs-5">
											<div class="input-group mb-0 text-center">
													<span class="input-group-text"> <strong> Rp.</strong> </span>
													<input class="form-control-lg border text-center" readonly placeholder="Total Bayar" min="0" type="number" name="total_bayar" id="total_bayar" onfocus="mulaiHitung()" onblur="stopHitung()" required>
											</div>
										</td>
								</tr>
								<tr>
										<td colspan="2" class="text-start fs-5" style="border-inline-end-color: white">
											<h4 class="mt-2 ms-2">Tunai </h4>
										</td>
										<td colspan="3" class="fs-5">
											<div class="input-group">
													<span class="input-group-text"> <strong>Rp.</strong> </span>
													<input type="number" placeholder="Pembayaran" name="tunai" class="form-control-lg border text-center" id="tunai" onfocus="mulaiHitung()" onblur="stopHitung()" required="" min="0">
												</div>
										</td>
								</tr>
								<tr>
										<td colspan="2" class="text-start" style="border-inline-end-color: white">
											<h4 class="mt-2 ms-2">Kembali </h4>
										</td>
										<td colspan="3" class="fs-5">
											<div class="input-group text-center">
													<span class="input-group-text"> <strong>Rp.</strong> </span>
													<input type="number" readonly placeholder="Kembali" name="kembali" class="form-control-lg bg-white border text-center" id="kembalian" onfocus="mulaiHitung()" onblur="stopHitung()" required="" min="0">
											</div>
										</td>
								</tr>
							</tbody>
					</table>
					<h6 class="text-center">Pastikan Pembayaran telah dilakukan sebelum klik OK</h6>
					<div class="modal-footer justify-content-center">
							<button type="button" class="btn btn-danger" data-bs-dismiss="modal">&nbsp;&nbsp; Batal<i class="bi bi-x"></i> &nbsp;&nbsp;</button>
							&nbsp;&nbsp;&nbsp;&nbsp;
							<button type="submit" class="btn btn-success" >&nbsp;&nbsp; Ok<i class="bi bi-check2"></i> &nbsp;&nbsp;</button>
					</div>

				</form>
				</div>
	</div>
</div>
</div><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/penjualan/ModalCheckout.blade.php ENDPATH**/ ?>