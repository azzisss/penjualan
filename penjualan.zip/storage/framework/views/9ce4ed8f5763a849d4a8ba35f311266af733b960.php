

<?php $__env->startSection('mainkonten'); ?>

<div class="container-fluid px-3 mt-4">
	<div class="row">
		<div class="d-flex justify-content-evenly flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h3 style="text-transform:capitalize" class="h4">Tambah Kategori Baru</h3>
		</div>
		

		 	<div class="d-flex justify-content-center">
				<div class="col-8">
					<form method="post" action="/category/posts" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<label for="title" class="form-label ms-3">Nama Kategori</label>
					<div class="input-group mb-3 ms-3">
						<input type="text" class="form-control <?php $__errorArgs = ['nama_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_category" name="nama_category" required value="<?php echo e(old('nama_category')); ?>">
						<button type="submit" id="button-addon2" class="btn btn-primary">Buat Kategori</button>
						<?php $__errorArgs = ['nama_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<div class="invalid-feedback" id="nama_category">
								<?php echo e($message); ?>

						</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					</form>
				</div>
		 	</div>
	</div>
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/category/posts/create.blade.php ENDPATH**/ ?>