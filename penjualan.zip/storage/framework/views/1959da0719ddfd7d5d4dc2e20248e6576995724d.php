

<?php $__env->startSection('mainkonten'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/laporan.blade.php ENDPATH**/ ?>