
	<div class="sticky-lg-top">
		<div class="card mb-3 brdblue">
		<div class="card-header border-primary " >
			<h5 class="mb-0 "><?php echo e($fitur1); ?></h5>
		</div>
		<div class="card-body">
			
				<table class="table">
					<thead>
					<tr>
						<th scope="col">No</th>
						<th scope="col">Item</th>
						<th scope="col">Harga</th>
						<th scope="col"class="text-center" >Jumlah</th>
					</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $cartitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<tr>
						<th scope="col-4"> <?php echo e($loop->iteration); ?> </th>
						<td scope="row">
							<p class="text-start fw-normal lh-sm">
								<?php echo e($item->nama_makanan); ?>

							</p>
						</td>
						<td>
							<p class="text-start fw-normal lh-sm">
								Rp. <?php echo e($item->harga_makanan); ?>

							</p>
						</td>
						<td>
							<div class="d-flex justify-content-start">
								<form action="/cart/<?php echo e($item->id); ?>" method="post">
								<?php echo method_field('patch'); ?>
								<?php echo csrf_field(); ?>
								<input type="hidden" name="param" value="kurang">
								<input type="hidden" name="qty" value="<?php echo e($item->qty); ?>" >
								<button class="btn btn-link btn-sm border-primary " style="margin-right: -1px;
								border-top-right-radius: 0;
								border-bottom-right-radius: 0;"
								onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
								<i class="fas fa-minus"></i>
								</button>
								</form>
								
								<form action="/updateqty/<?php echo e($item->id); ?>" method="post">
								<?php echo csrf_field(); ?>
								<input min="0" name="qty" value="<?php echo e($item->qty); ?>" type="number" style="width: 4em" id="myInput"
								class="form-control form-control-sm border-primary rounded-0" />
								<button type="submit" id="myBtn" hidden></button>
								</form>
								

								<form action="/cart/<?php echo e($item->id); ?>" method="post">
								<?php echo method_field('patch'); ?>
								<?php echo csrf_field(); ?>
								<input type="hidden" name="param" value="tambah">
								<button class="btn btn-link btn-sm border-primary" style="margin-left: -1px;
								border-top-left-radius: 0;
								border-bottom-left-radius: 0;"
								onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
								<i class="fas fa-plus"></i>
								</button>
								</form>
							</div>
						</td>
						<td>
							<div class="">
								<form action="/deletelist/<?php echo e($item->id); ?>" method="post">
								<?php echo csrf_field(); ?>
								<button class="btn-sm btn-danger">X</button>
								</form>
							</div>
						</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr class="border">
						<td colspan="2"><b>Total</b></td>
						<td colspan="2"><b>Rp <?php echo e(number_format($total,2,",",".")); ?></b></td>
					</tr> 
					</tbody>
				</table>
				<div class="d-flex justify-content-end">
					<?php if($total == 0): ?>
					<button type="button" class="btn btn-danger me-3" disabled>Hapus</button>
					<button type="button" class="btn btn-primary" disabled>Checkout</button>
					<?php else: ?>
					<button type="button" class="btn btn-danger me-3" data-bs-toggle="modal" href="#exampleModal1">Hapus</button>
					<button type="button" class="btn btn-primary" data-bs-toggle="modal" href="#exampleModal2" >Checkout</button>
					<?php endif; ?>
				</div>
			</form>
		</div>
		</div>
	</div>
<?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/penjualan/CartP1.blade.php ENDPATH**/ ?>