<?php if( session()->has('berhasil')): ?>
	<div class="alert alert-success alert-dismissible fade show text-capitalize text-center fw-semibold fs-6 mt-2" role="alert">
				<?php echo e(session('berhasil')); ?>

		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
	</div>
<?php elseif(session()->has('hapus')): ?>
	<div class="alert alert-danger alert-dismissible fade show text-capitalize text-center fw-semibold fs-6 mt-2" role="alert">
		<?php echo e(session('hapus')); ?>

		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
<?php elseif(session()->has('update')): ?>
	<div class="alert alert-warning alert-dismissible fade show text-capitalize text-center fw-semibold fs-6 mt-2" role="alert">
		<?php echo e(session('update')); ?>

		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
	</div>
<?php endif; ?> <?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/partials/massage.blade.php ENDPATH**/ ?>