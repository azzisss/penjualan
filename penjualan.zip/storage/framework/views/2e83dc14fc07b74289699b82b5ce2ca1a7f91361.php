

<?php $__env->startSection('mainkonten'); ?>
<div class="container">
	<div class="card my-4">
		<div class="fs-6">
			<div class="card-header text-center">
				<h5>Data Kategori Makanan</h5>
			</div>
			<div class="card-body">
				<div class="row">
					<div class="col-1 me-3">
						<select class="form-select form-select-sm" wire:model="paginate">
							<option value="5" >5</option>
							<option value="10">10</option>
							<option value="15">15</option>
							<option value="20">20</option>
							<option value="25">25</option>
							<option value="30">30</option>
						 </select>
							<?php echo e($paginate); ?>

					</div>
					<div class="col-7">
						<a href="/category/create" class="btn btn-success mb-2"> Tambah Data Kategori </a>
					</div>
					<div class="col-3 justify-content-end sm-auto">
						<div class="mb-3">
							<input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="search...">
						 </div>
					</div>
				</div>
				<table class="table table-bordered" id="myTable" >
					<thead>
					  <tr>
						 <th scope="col" class="no text-center">
							No
							<span class="text-sm float-end" style="cursor: pointer;">
								<i class="bi bi-arrow-down-up" style="height: 15px; width:10px" ></i>
							</span>
						</th>
						<th scope="col" >
							Nama Kategori
							<span class="text-sm float-end" style="cursor: pointer;">
								<i class="bi bi-arrow-down-up" style="height: 15px; width:10px"></i>
							</span>
						</th>
						<th scope="col">Action</th>
					  </tr>
					</thead>
					<tbody class="table-group-divider">
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						  <th scope="row" class="no text-center"><?php echo e($loop->iteration); ?></th>
						  <td ><?php echo e($item->nama_category); ?></td>
						  <td></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<?php echo e($categories->links()); ?>

				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<script>
	function myFunction() {
	  // Declare variables
	  var input, filter, table, tr, td, i, txtValue;
	  input = document.getElementById("myInput");
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");
	
	  // Loop through all table rows, and hide those who don't match the search query
	  for (i = 0; i < tr.length; i++) {
		 td = tr[i].getElementsByTagName("td")[0];
		 if (td) {
			txtValue = td.textContent || td.innerText;
			if (txtValue.toUpperCase().indexOf(filter) > -1) {
			  tr[i].style.display = "";
			} else {
			  tr[i].style.display = "none";
			}
		 }
	  }
	}
</script>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/livewire/category/index.blade.php ENDPATH**/ ?>