

<?php $__env->startSection('mainkonten'); ?>
<div class="container-fluid px-4 mt-4">
	<h1 class="">Operator</h1>
		<ol class="breadcrumb mb-2 ">
            <li class="breadcrumb-item"><a href="/operator">Operator</a></li>
			<li class="breadcrumb-item active">Edit</li>
		</ol>
		<hr>
        <div class="row justify-content-center">
            <div class="col-sm-7">
                <?php if(session()->has('changepass')): ?>
                    <div class="alert alert-success alert-dismissible fade show text-capitalize text-center fw-semibold fs-6 mt-2"
                        role="alert">
                        <?php echo e(session('changepass')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
            </div>
            <div class="d-flex justify-content-evenly flex-wrap flex-md-nowrap text-center pt-3 pb-2 mb-3 ">
                <h3 style="text-transform:capitalize" class="h4">Edit Operator</h3>
            </div>
            <div class="d-flex justify-content-center">
                <div class="col-lg-8">
                    <form action="/operator/<?php echo e($operator->id); ?>" method="post" enctype="multipart/form-data">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Operator</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                                name="name" required value="<?php echo e(old('name', $operator->name)); ?>">

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" id="name">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="mb-3">
                            <label for="username">Username</label>
                            <input type="text" autocomplete='off'
                                class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" name="username"
                                placeholder="Username" value="<?php echo e(old('username', $operator->username)); ?>">
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" id="username">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="mb-3">
                            <label for="email">Email</label>
                            <input type="email" autocomplete='off'
                                class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email"
                                placeholder="name@example.com" value="<?php echo e(old('email', $operator->email)); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" id="email">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="mb-3">
                            <label for="id_akses">Akses</label>
                            <select class="form-select <?php $__errorArgs = ['id_akses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_akses"
                                name="id_akses" value="<?php echo e(old('id_akses')); ?>" required>
                                <option value="" selected>Pilih Akses</option>
                                <?php $__currentLoopData = $akses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(old('id_akses', $operator->id_akses) == $item->id): ?>
                                        <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->nama_akses); ?>

                                            <?php echo e($item->deskripsi_akses); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_akses); ?>

                                            <?php echo e($item->deskripsi_akses); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['id_akses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" id="id_akses">
                                    <?php echo e('The Akses field is required.'); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="mb-3">
                            <a href="/changepass/<?php echo e($operator->id); ?>" class="btn-sm btn-secondary">Change Password</a>
                        </div>
                        <div class="d-flex justify-content-center">
                            <div class="col-3 text-center">
                                <button class="btn btn-primary" type="submit">Update</button>
                            </div>

                        </div>
                    </form>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/operator/edit.blade.php ENDPATH**/ ?>