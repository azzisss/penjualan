<nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="/dashboard" class=""><img src="/img/logo.png" class="img-fluid logojagosore" style="height:50px"alt="">Jagosore</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link <?php echo e(($active == 'dashboard') ? 'active' : ''); ?>" aria-current="page" href="/dashboard">Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($active == 'penjualan') ? 'active' : ''); ?>" href="/">Penjualan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($active == 'laporan') ? 'active' : ''); ?>" href="/laporan">Laporan</a>
          </li>
        </ul>
      </div>
    </div>
  </nav><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/partials/header.blade.php ENDPATH**/ ?>