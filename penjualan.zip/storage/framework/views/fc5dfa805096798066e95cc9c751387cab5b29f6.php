

<?php $__env->startSection('mainkonten'); ?>
<div class="container-fluid px-4">
 <h1 class="mt-4">Laporan Tahunan</h1>
 <ol class="breadcrumb mb-4">
  <li class="breadcrumb-item"><a href="/laporan">Laporan</a> </li>
  <li class="breadcrumb-item active" aria-current="page">Laporan Tahunan</li>
 </ol>
 <div class="row mb-3 justify-content-center">
  <div class=" col-sm-3">
   <div class="card border-secondary mb-2" style="height: 6.5em">
    <div class="card-header bg-secondary text-white">
     Tahun
    </div>
    <div class="card-body">
     <h5 class="text-center"><?php echo e($tahun); ?></h5>
    </div>
   </div>
  </div>
  <div class="col-sm-3">
   <div class="card border-primary mb-2" style="height: 6.5em">
    <div class="card-header bg-primary text-white">
     Makanan Terjual
    </div>
    <div class="card-body">
     <h5 class="card-title text-center"><?php echo e($mkntrjl); ?> Makanan</h5>
    </div>
   </div>
  </div>
  <div class="col-sm-3">
   <div class="card border-success mb-2" style="height: 6.5em">
    <div class="card-header bg-success text-white">
     Pendapatan
    </div>
    <div class="card-body">
     <h5 class="card-title text-center">Rp. <?php echo e(number_format($pendapatan,2,",",".")); ?></h5>
    </div>
   </div>
  </div>
 </div>
 <div class="row mb-3 justify-content-center">
  
<div class="col-sm-10">
 <div class="card">
  <div class="card-header text-center">
   <h5>Laporan Tahunan</h5>
  </div>
  <div class="card-body">
   <?php
   use App\Models\Checkout;
   // Set your timezone
   date_default_timezone_set('Asia/Jakarta');

   // Get prev & next month
   if (isset($_GET['year'])) {
   $ym = $_GET['year'];
   } else {
   // This month
   $ym = date('Y');
   }

   // Check format
   $timestamp = strtotime($ym . '-01');
   if ($timestamp === false) {
   $ym = date('Y');
   $timestamp = strtotime($ym . '-01');
   }
  
   $year = date('Y', $timestamp);
   $yearnow = date('Y');

   // You can also use strtotime!
   $prev = date('Y', strtotime('-1 year', $timestamp));
   $next = date('Y', strtotime('+1 year', $timestamp));


   ?>
   <div class="text-center">
    <div class="d-flex justify-content-evenly">
     <h3><a class="btn btn-primary" href="tahunan?year=<?php echo e($prev); ?>">
       <<</a>
     </h3>
     <h3><?php echo e($year); ?></h3>
     <h3><a class="btn btn-primary" href="?year=<?php echo e($next); ?>">>></a></h3>
    </div>
   </div>
   <div class="table-responsive">
    <table class="table table-bordered table-success">
     <tbody class="text-center">
      
      <td id="bln" style="font-weight: 500" class="<?php if( date('Y', strtotime('-2 year', $timestamp)) == $yearnow  ){echo "bg-danger fs-6 bg-opacity-25";} ?>"><a class="text-black" style='cursor:pointer; text-decoration:none;' href="tahunan?year=<?php echo e(date('Y', strtotime('-2 year', $timestamp))); ?>"><?php echo e(date('Y', strtotime('-2 year', $timestamp))); ?><br>Rp <?php echo e(number_format(Checkout::whereYear('created_at', date('Y', strtotime('-2 year', $timestamp)))->get()->sum('total_bayar'),0,",",".")); ?></a></td>

      <td id="bln" style="font-weight: 500" class="<?php if( date('Y', strtotime('-1 year', $timestamp)) == $yearnow  ){echo "bg-danger fs-6 bg-opacity-25";} ?>"><a class="text-black" style='cursor:pointer; text-decoration:none;' href="tahunan?year=<?php echo e(date('Y', strtotime('-1 year', $timestamp))); ?>"><?php echo e(date('Y', strtotime('-1 year', $timestamp))); ?><br>Rp <?php echo e(number_format(Checkout::whereYear('created_at', date('Y', strtotime('-1 year', $timestamp)))->get()->sum('total_bayar'),0,",",".")); ?></a></td>
      
      <td id="bln" style="font-weight: 500" class="<?php if( $year == $yearnow  ){echo "bg-danger fs-6 bg-opacity-25";} ?>"><a class="text-black" style='cursor:pointer; text-decoration:none;' href="tahunan?=<?php echo e($year); ?>"><?php echo e($year); ?><br>Rp <?php echo e(number_format(Checkout::whereYear('created_at', $year)->get()->sum('total_bayar'),0,",",".")); ?></a></td>
      
      <td id="bln" style="font-weight: 500" class="<?php if( date('Y', strtotime('+1 year', $timestamp)) == $yearnow  ){echo "bg-danger fs-6 bg-opacity-25";} ?>"><a class="text-black" style='cursor:pointer; text-decoration:none;' href="tahunan?=<?php echo e(date('Y', strtotime('+1 year', $timestamp))); ?>" ><?php echo e(date('Y', strtotime('+1 year', $timestamp))); ?><br>Rp <?php echo e(number_format(Checkout::whereYear('created_at', date('Y', strtotime('+1 year', $timestamp)))->get()->sum('total_bayar'),0,",",".")); ?></a></td>
      
      <td id="bln" style="font-weight: 500" class="<?php if( date('Y', strtotime('+2 year', $timestamp)) == $yearnow  ){echo "bg-danger fs-6 bg-opacity-25";} ?>"><a class="text-black" style='cursor:pointer; text-decoration:none;' href="tahunan?=<?php echo e(date('Y', strtotime('+2 year', $timestamp))); ?>"><?php echo e(date('Y', strtotime('+2 year', $timestamp))); ?><br>Rp <?php echo e(number_format(Checkout::whereYear('created_at', date('Y', strtotime('+2 year', $timestamp)))->get()->sum('total_bayar'),0,",",".")); ?></a></td>
      
     </tbody>
    </table>
    <i>*klik tahun tertentu untuk memilih tahun</i>

   </div>
  </div>
 </div>
</div>
</div>
<div class="row mb-3 justify-content-center">
 <div class="col-sm-10">
  <div class="card">
   <div class="card-header">
    <h5 class="card-title text-center">Laporan Penjualan Tahun <?php echo e($tahun); ?></h5>
   </div>
   <div class="card-body">
    <div class="table-responsive">
     <table id="example" class="table table-hover" style="width:100%">
      <thead>
       <tr>
        <th>No</th>
        <th>No Pesanan</th>
        <th>User</th>
        <th>Total Harga</th>
        <th>Diskon</th>
        <th>Total Bayar</th>
        <th>Tunai</th>
        <th>Kembali</th>
        <th>Waktu</th>
        <th>Detail</th>
       </tr>
      </thead>
      <tbody>
       <?php $__currentLoopData = $tabelC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($item->no_pesanan); ?></td>
        <td><?php echo e($item->user); ?></td>
        <td>Rp. <?php echo e(number_format($item->total_harga)); ?></td>
        <td><?php echo e($item->diskon); ?> %</td>
        <td>Rp. <?php echo e(number_format($item->total_bayar)); ?></td>
        <td>Rp. <?php echo e(number_format($item->tunai)); ?></td>
        <td>Rp. <?php echo e(number_format($item->kembali)); ?></td>
        <td><?php echo e($item->created_at); ?></td>
        <td>
         <a href="/show/<?php echo e($item->id); ?>" class="badge bg-info mx-1 my-0.5">
          <i class="bi bi-eye fs-6"></i>
         </a>
        </td>
       </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
     </table>
    </div>

   </div>
  </div>
 </div>
</div>
<div class="row mb-3 justify-content-center">
 <div class="col-sm-10">
  <div class="card">
   <div class="card-header">
    <h5 class="card-title text-center">Makanan Terjual Tahun <?php echo e($tahun); ?></h5>
   </div>
   <div class="card-body">
    <table id="example2" class="table table-hover" style="width:100%">
     <thead>
      <tr>
       <th>No</th>
       <th>Nama Makanan</th>
       <th>Terjual</th>
      </tr>
     </thead>
     <tbody>
      <?php $__currentLoopData = $tabelMT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
       <td><?php echo e($loop->iteration); ?></td>
       <td><?php echo e($item->nama_makanan); ?></td>
       <td><?php echo e($item->sum); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </tbody>
    </table>

   </div>
  </div>
 </div>
</div>
</div>

<script>
$(document).ready(function() {
    table1();
				table2();
} );
function table1() {
	var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf','print' ]
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-md-6:eq(0)' );
}
function table2() {
	$(document).ready(function () {
    $('#example2').DataTable();
});
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/laporan/tahunan/tahunan.blade.php ENDPATH**/ ?>