
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">Menu</div>
                    <a class="nav-link <?php echo e(($active == 'penjualan') ? 'active' : ''); ?>" href="/">
                        <div class="sb-nav-link-icon active"><i class="bi bi-grid-3x3-gap-fill"></i></div>
                        Penjualan
                    </a>
                    <?php if(Auth::user()->id_akses==1): ?>
                    <a class="nav-link <?php echo e(($active == 'operator') ? 'active' : ''); ?>" href="/operator">
                        <div class="sb-nav-link-icon"><i class="bi bi-people-fill"></i></div>
                        Operator
                    </a>
                    <a class="nav-link <?php echo e(($active == 'laporan') ? 'active' : ''); ?>" href="/laporan">
                        <div class="sb-nav-link-icon"><i class="bi bi-clipboard-data-fill"></i></div>
                        Laporan
                        <div class="sb-sidenav-collapse-arrow"></div>
                    </a>
                    <?php endif; ?>
                    
                    
                    <div class="sb-sidenav-menu-heading">Data Penjualan</div>
                    <a class="nav-link <?php echo e(($active == 'makanan') ? 'active' : ''); ?>" href="/makanan">
                        <div class="sb-nav-link-icon"><i class="bi bi-basket2-fill"></i></div>
                        Makanan
                    </a>
                    <a class="nav-link <?php echo e(($active == 'category') ? 'active' : ''); ?>" href="/category">
                        <div class="sb-nav-link-icon"><i class="bi bi-bookmarks-fill"></i></div>
                        Kategori
                    </a>
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Logged in as :
                    <?php if(Auth::user()->id_akses==1): ?>
                    Admin
                    <?php else: ?>
                    Kasir
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </div><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/partials/sidenav.blade.php ENDPATH**/ ?>