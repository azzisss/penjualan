
<?php $__env->startSection('mainkonten'); ?>
<div class="container-fluid px-4 py-4">
 <div class="row">
  
  <div class="row justify-content-center">
   <div class="col-md-8">
    <?php if($errors->has('kembali')): ?>
    <div class="alert alert-danger alert-dismissible fade show text-capitalize text-center fw-semibold fs-5 my-2 mx-2"
     role="alert">
     <p>
      <i class="bi bi-x-octagon-fill"></i> Pembayaran kurang checkout gagal
     </p>
     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
   </div>
  </div>

  
  <div class="col-lg-5">
   <div class="sticky-lg-top">
    <div class="card mb-3 brdblue">
    <div class="card-header border-primary ">
     <h5 class="mb-0 "><?php echo e($fitur1); ?></h5>
    </div>
    <div class="card-body">
     
     <table class="table">
      <thead>
       <tr>
        <th scope="col">No</th>
        <th scope="col">Item</th>
        <th scope="col">Harga</th>
        <th scope="col"class="text-center">Jumlah</th>
       </tr>
      </thead>
      <tbody>
        <tr>
        <th scope="col-4"> </th>
        <td scope="row">
         <p class="text-start fw-normal lh-sm">
          
         </p>
        </td>
        <td>
         <p class="text-start fw-normal lh-sm">
          Rp 
         </p>
        </td>
        <td>
         <div class="d-flex justify-content-start">

           <input type="hidden" name="param" value="kurang">
           <input type="hidden" name="qty" value="">
           <button class="btn btn-link btn-sm border-primary "
            style="margin-right: -1px;border-top-right-radius: 0; border-bottom-right-radius: 0;"
            onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
            <i class="fas fa-minus"></i>
           </button>
          </form>


           <input min="0" name="qty" value=""
            type="number" style="width: 4em" id="myInput"
            class="form-control form-control-sm border-primary rounded-0" />
           <button type="submit" id="myBtn" hidden></button>


           <input type="hidden" name="param" value="tambah">
           <button class="btn btn-link btn-sm border-primary"
            style="margin-left: -1px;
                                      border-top-left-radius: 0;
                                      border-bottom-left-radius: 0;"
            onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
            <i class="fas fa-plus"></i>
           </button>
          </form>
         </div>
        </td>
        <td>
         <div class="">

           <button class="btn-sm btn-danger">X</button>

         </div>
        </td>
        </tr>

       <tr class="border">
        <td colspan="2"><b>Total</b></td>
        <td colspan="2"><b>Rp </b></td>
       </tr>
      </tbody>
     </table>
     <div class="d-flex justify-content-end">
      <?php if($total == 0): ?>
       <button type="button" class="btn btn-danger me-3" disabled>Hapus</button>
       <button type="button" class="btn btn-primary" disabled>Checkout</button>
      <?php else: ?>
       <button type="button" class="btn btn-danger me-3" data-bs-toggle="modal"
        href="#exampleModal1">Hapus</button>
       <button type="button" class="btn btn-primary" data-bs-toggle="modal"
        href="#exampleModal2">Checkout</button>
      <?php endif; ?>
     </div>
     </form>
    </div>
    </div>
   </div>
  </div>

        
  <div class="col-lg-7">
   <div class="card brdblue card-order1 brdorange">
    <div class="card-header border-primary ">
    <h5 class="mb-0"><?php echo e($fitur2); ?></h5>
    </div>
    <div class="card-body">
    <div
     class="dropdown d-flex content-start d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
     <a class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown">
      Kategori
     </a>
     <ul class="dropdown-menu">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <li>
        <a class="dropdown-item"
        href="#scrollspyHeading<?php echo e($sc++); ?>"><?php echo e($category->nama_category); ?></a>
       </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
    </div>
    <div class="d-flex content-end d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
    <form action="/" method="get">			
       <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Search.." name="search" value="<?php echo e(request('search')); ?> " autocomplete="off" >
        <button class="btn btn-primary border" type="submit">Search</button>
       </div>
       </form>
    </div>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <hr id="scrollspyHeading<?php echo e($sc2++); ?>">
     <div class="card border-primary">
      <div class="card-header d-flex content-start bg-primary border-primary"
       style="height: 2.5rem">
       <div class="col-1"></div>
       <div class="col-8">
        <p class="text-center mb-1 text-white"><b><?php echo e($category->nama_category); ?></b>
        <p>
       </div>
       <div class="col-3">
        <i class="bi bi-caret-down-square" data-bs-toggle="collapse"
        data-bs-target="#multiCollapseExample<?php echo e($col++); ?>"
        aria-expanded="true" style="cursor:pointer"></i>
       </div>
      </div>
      <div class="card-body my-0  brdorange">
       <div class="collapse.show multi-collapse"
        id="multiCollapseExample<?php echo e($col2++); ?>">
        <table class="table table-hover">
        <tbody>
         <?php $__currentLoopData = $makanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $makanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($makanan->category_id == $category->id): ?>
           <tr>
            <td>
             <input type="hidden" name="makanan_id"
              value="<?php echo e($makanan->id); ?>">
             <input type="hidden" name="nama_makanan"
              value="<?php echo e($makanan->nama_makanan); ?>">
             <input type="hidden" name="harga_makanan"
              value="<?php echo e($makanan->harga_makanan); ?>">
             <input type="hidden" name="qty" value="1">
             <input type="hidden" name="subtotal"
              value="<?php echo e($makanan->harga_makanan); ?>">
             <button type="submit" class="btn btn-primary mt-2 ">
              <i class="bi bi-cart-plus"></i>
             </button>
            </td>
            <td>
            <?php if($makanan->gambar): ?>
             <img height="60" width="60"
              src="<?php echo e(asset('storage/' . $makanan->gambar)); ?>"
              alt="">
            <?php else: ?>
             <img height="60" width="60"
              src="https://source.unsplash.com/600x400?<?php echo e($makanan->nama_makanan); ?>"
              alt="">
            <?php endif; ?>
            </td>
            <td><b><?php echo e($makanan->nama_makanan); ?></b></td>
            <td><?php echo e($makanan->keterangan_makanan); ?></td>
            <td><b>Rp <?php echo e(number_format($makanan->harga_makanan,0,",",".")); ?></b></td>
           </tr>
          <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
       </div>
      </div>
     </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
   </div>
  </div>

  
  <div class="modal fade" id="exampleModal1" aria-hidden="true" tabindex="-1" data-bs-backdrop="static"
   data-bs-keyboard="true">
   <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
    </div>
    <div class="modal-body text-center">
     Yakin Akan Hapus Keranjang?
    </div>
    <div class="modal-footer justify-content-center">
     <form action="/deletecart" method="post">
      <?php echo csrf_field(); ?>
      <button type="button" class="btn btn-danger" data-bs-dismiss="modal">&nbsp;&nbsp; Tidak<i
        class="bi bi-x"></i> &nbsp;&nbsp;</button>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <button type="submit" class="btn btn-success" id="myBtn">&nbsp;&nbsp; Iya<i
        class="bi bi-check2"></i> &nbsp;&nbsp;</button>
     </form>
    </div>
    </div>
   </div>
  </div>

 
  <div class="modal fade" id="exampleModal2" data-bs-backdrop="static" data-bs-keyboard="true">
   <div class="modal-dialog modal-lg">
    <div class="modal-content">
    <div class="modal-header">
     <img src="<?php echo e(asset('/img/logo.png')); ?>" class="rounded mx-auto d-block" height="100"
      width="100" alt="...">
    </div>
    <div class="modal-body">
     <form action="/checkout" method="post">
      <?php echo csrf_field(); ?>
      <table class="table table-bordered">
       <thead>
        <tr>
        <th scope="col" class="text-center">No</th>
        <th scope="col" class="text-center">Item</th>
        <th scope="col" class="text-center">Harga</th>
        <th scope="col" class="text-center">Jumlah</th>
        <th scope="col" class="text-center">Subtotal</th>
        </tr>
       </thead>
       <tbody>
        <?php $__currentLoopData = $cartitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
         <th class="text-center"><?php echo e($loop->iteration); ?>

          <input type="hidden" name="makanan_id" id=""
           value="<?php echo e($item->id); ?>">
         </th>
         <td class="fw-semibold"><?php echo e($item->nama_makanan); ?>

          <input type="hidden" name="nama_makanan" id=""
           value="<?php echo e($item->nama_makanan); ?>">
         </td>
         <td class="text-center ">Rp.
          <?php echo e(number_format($item->harga_makanan, 0, ',', '.')); ?>

          <input type="hidden" name="harga_makanan" id=""
           value="<?php echo e($item->harga_makanan); ?>">
         </td>
         <td class="text-center "><?php echo e($item->qty); ?>

          <input type="hidden" name="qty" id=""
           value="<?php echo e($item->qty); ?>">
         </td>
         <td class="text-center ">Rp.
          <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?>

          <input type="hidden" name="subtotal" id=""
           value="<?php echo e($item->subtotal); ?>">
         </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td colspan="2" class="text-start" style="border-inline-end-color: white">
         <h6 class="mt-2 ms-2">Total Harga </h6>
        </td>
        <td colspan="3" class="text-center ">
         <input type="hidden" name="total_harga" id="total_harga"
          value="<?php echo e($total); ?>">
         <h5 class="mt-2 ms-2">Rp <?php echo e(number_format($total, 0, ',', '.')); ?></h5>

        </td>
        </tr>
        <tr class="">
        <td colspan="2" class="text-start "
         style="border-inline-end-color: white">
         <h6 class="mt-2 ms-2">Diskon </h6>
        </td>
        <td colspan="3" class="fs-5 text-end">
         <div class="input-group mb-0 text-center">
          <input class="form-control border bg-white border text-center" placeholder="Diskon"
           min="0" max="100" type="number" name="diskon"
           id="diskon" onfocus="mulaiHitung()" onblur="stopHitung()"
           value="0" required style="max-width: 18rem">
          <span class="input-group-text ">%</span>

         </div>
        </td>
        </tr>
        <tr>
        <td colspan="2" class="text-start fs-5"
         style="border-inline-end-color: white">
         <h6 class="mt-2 ms-2">Total Bayar </h6>
        </td>
        <td colspan="3" class="fs-5">
         <div class="input-group mb-0 text-center">
          <span class="input-group-text"> <strong> Rp.</strong> </span>
          <input class="form-control border text-center fs-bolder" readonly
           placeholder="Total Bayar" min="0" type="number"
           name="total_bayar" id="total_bayar" onfocus="mulaiHitung()"
           onblur="stopHitung()" required>
         </div>
        </td>
        </tr>
        <tr>
        <td colspan="2" class="text-start fs-5"
         style="border-inline-end-color: white">
         <h6 class="mt-2 ms-2">Tunai </h6>
        </td>
        <td colspan="3" class="fs-5">
         <div class="input-group">
          <span class="input-group-text"> <strong>Rp.</strong> </span>
          <input type="number" placeholder="Pembayaran" name="tunai"
           class="form-control border text-center" id="tunai"
           onfocus="mulaiHitung()" onblur="stopHitung()" required=""
           min="0">
         </div>
        </td>
        </tr>
        <tr>
        <td colspan="2" class="text-start" style="border-inline-end-color: white">
         <h6 class="mt-2 ms-2">Kembali </h6>
        </td>
        <td colspan="3" class="fs-5">
         <div class="input-group text-center">
          <span class="input-group-text"> <strong>Rp.</strong> </span>
          <input type="number" readonly placeholder="Kembali" name="kembali"
           class="form-control bg-white border text-center" id="kembalian"
           onfocus="mulaiHitung()" onblur="stopHitung()" required=""
           min="0">
         </div>
        </td>
        </tr>
       </tbody>
      </table>
      <h6 class="text-center">Pastikan Pembayaran telah dilakukan sebelum klik OK</h6>
      <div class="modal-footer justify-content-center">
       <button type="button" class="btn btn-danger" data-bs-dismiss="modal">&nbsp;&nbsp;
        Batal<i class="bi bi-x"></i> &nbsp;&nbsp;</button>
       &nbsp;&nbsp;&nbsp;&nbsp;
       <button type="submit" class="btn btn-success">&nbsp;&nbsp; Ok<i
        class="bi bi-check2"></i> &nbsp;&nbsp;</button>
      </div>

     </form>
    </div>
    </div>
   </div>
  </div>

  
 </div>
</div>

<script>
 var input = document.getElementById("myInput");
 input.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
   event.preventDefault();
   document.getElementById("myBtn").click();
  }
 });
</script>

<script>
 function mulaiHitung() {
  interval = setInterval("Hitung()", 1);
 }

 function Hitung() {
  harga_awal = document.getElementById("total_harga").value;
  diskon = document.getElementById("diskon").value;
  diskon2 = (harga_awal * diskon) / 100;
  harga_total = harga_awal - diskon2;
  harga_final = document.getElementById("total_bayar").value =
  Math.round(harga_total);
  tunai = document.getElementById("tunai").value;
  kembalian = tunai - harga_final;
  document.getElementById("kembalian").value = kembalian;
  document.getElementById("total_bayar").value = harga_final;
  document.getElementById("tunai").value = tunai;
 }

 function stopHitung() {
  clearInterval(interval);
 }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEMESTER 8\aplikasi\penjualan\resources\views/penjualan2.blade.php ENDPATH**/ ?>