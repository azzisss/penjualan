<?php return array (
  'cart' => 'App\\Http\\Livewire\\Cart',
  'home' => 'App\\Http\\Livewire\\Home',
);