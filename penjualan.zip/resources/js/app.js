import './bootstrap';
require('./bootstrap');  
